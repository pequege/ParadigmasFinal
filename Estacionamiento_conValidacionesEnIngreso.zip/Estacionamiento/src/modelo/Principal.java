
package modelo;

import controlador.Controlador;
import java.util.Calendar;
import vista.VentanaPrincipal;

public class Principal {

    public static void main(String[] args) {
        controlador.Controlador c = new Controlador();
        c.IniciarPrograma();
        System.out.println();
    }
    
}
