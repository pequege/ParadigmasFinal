package modelo;
public class Producto {
    private String nombre;
    private int precio;
}
