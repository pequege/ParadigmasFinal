package modelo;
public class Lavado {
    private boolean estado;

    public Lavado(boolean estad) {
        estado = estad;
    }

    public boolean isEstado() {
        return estado;
    }

    public void setEstado(boolean estado) {
        this.estado = estado;
    }
    
}
